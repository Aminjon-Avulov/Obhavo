const projectData={};
// Express to run server and routes
const express = require('express')
// Start up an instance of app
const app = express();

const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

const cors = require('cors');
app.use(cors());

app.use(express.static('website'));

const port = 2006;
const server = app.listen(port,listening);
function listening(){
    console.log('Server ishlamoqda');
    console.log(`Server ${port} portda ishlamoqda`)
}

// app.get('/add',amin);
// function amin(req,res){
//     // console.log(req);
//     res.send(appData)
    
// };
// const data=[];
// app.post('/addAnimal',addAnimal);
// function addAnimal(req,res){
    
//     data.push(req.body);
//     console.log(data)
// };
const faceData={
    animal:"lion",
    fact:"lion are years"
}

app.get('/fakeAnimalData',getFakeData)
function getFakeData(req,res) {
    res.send(faceData)
};

const animalData = [];

app.get('/add',amin);
function amin(req,res){
    // console.log(req);
    res.send(animalData);
    console.log(animalData)
};

// POST
app.post('/addAnimal',addAnimal);
function addAnimal(req,res){
    console.log(req.body)
    newEntry={
        animal:req.body.animal,
        temp:req.body.temp,
        fav:req.body.fav
    }
    animalData.push(newEntry)
    res.send(animalData)
    console.log(animalData)
}
