/* WEB API WITH FETCH DEMO--  */
let baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip='
const apiKey = 'de3894781157945d89e50b78bb412d6c';

let d = new Date();
let newDate = d.getDate() + '.' + (d.getMonth()+1) + '.' + d.getFullYear();


document.getElementById('generate').addEventListener('click', performAction);

function performAction(e){  
  const fav = document.getElementById('feelings').value;
  const zipCode =  document.getElementById('zip').value;
  if(document.getElementById('zip').value!=''){
  let finalUrl=`${baseURL}${zipCode},us&appid=${apiKey}&units=metric`;
  console.log(finalUrl);
  // 
  getAnimalDemo(finalUrl).then((data) => {
    // 
    console.log(data);
    postData('/addAnimal',{animal:data.name,temp:data.main.temp,fav:fav, icon:data.weather.icon});
    // 
    
      updateUI()
 
  })
};
};




const getAnimalDemo = async (url)=>{
// 1.
  // const res = await fetch(baseURL+animal+key)
// 2. Call Fake 

  const res = await fetch(url)
  try {

    const data = await res.json();
    console.log(data)
    // 1. We can do something with our returned data here-- like chain promises!
    return data;
    // 2. 
    // postData('/addAnimal', data)
  }  catch(error) {
    // appropriately handle the error
    console.log("error", error);
  }
}

const postData = async ( url = '', data = {})=>{
    // console.log(data);
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
     // Body data type must match "Content-Type" header        
      body: JSON.stringify(data), 
    });

      try {
        const newData = await response.json();
        console.log(newData);
        return newData;
      }catch(error) {
      console.log("error", error);
      }
  };

// postData('/addAnimal', {answer:42});
const updateUI = async () => {
  const request = await fetch('/add');
  try{
    const data = await request.json();
    console.log(data)
    
    let dataIndex = data.length-1;
    console.log(dataIndex)
    document.getElementById('animalData').innerHTML = data[dataIndex].animal;
    document.getElementById('animalFact').innerHTML = data[dataIndex].temp+"°C";
    document.getElementById('dates').innerHTML = newDate;
    document.getElementById('animalFav').innerHTML = data[dataIndex].fav;

  }catch(error){
    console.log("error", error);
  }
};